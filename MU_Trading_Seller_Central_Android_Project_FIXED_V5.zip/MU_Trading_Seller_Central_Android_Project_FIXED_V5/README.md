# MU Trading Seller Central Android

Android WebView wrapper for the existing Seller Central HTML.

Package ID: `com.mutradingsellercentral`
Version: `1.0` (versionCode 1)

The supplied Seller Central HTML is packaged as `app/src/main/assets/index.html` and keeps its Supabase integration.


V5 fix: Android product loading now has a direct Supabase REST fallback when the Supabase JavaScript client/CDN is unavailable in WebView.
