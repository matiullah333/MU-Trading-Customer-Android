MU Trading Customer Android Project

This project wraps the MU Trading Customer Shop HTML into a native Android WebView app.
The customer HTML is bundled in app/src/main/assets/index.html.

Open this folder in Android Studio and build the debug APK with:
./gradlew assembleDebug

Application ID: com.mutrading.customer
Version: 1.0 (code 1)
